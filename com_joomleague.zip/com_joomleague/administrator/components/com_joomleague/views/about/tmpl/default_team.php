<?php
/**
 * Joomleague
*
* @copyright	Copyright (C) 2006-2015 joomleague.at. All rights reserved.
* @license     GNU General Public License version 2 or later; see LICENSE.txt
* @link		http://www.joomleague.at
*/
defined('_JEXEC') or die;
?>
<fieldset class="form-horizontal">
	<p class="alert alert-info">Information about the JL-team</p>
</fieldset>


<fieldset>
<legend>Developers</legend>
	Information about our Developers can be found:
	<a href="https://gitlab.com/joomleague/joomleague/graphs/master" target="_blank">over here</a>
</fieldset>

