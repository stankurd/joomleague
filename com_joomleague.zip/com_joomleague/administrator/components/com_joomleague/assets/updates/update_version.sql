update #__joomleague_version set major='4', minor='0', build='22', revision='57ae969', version='Beta', file='joomleague' where id=1
