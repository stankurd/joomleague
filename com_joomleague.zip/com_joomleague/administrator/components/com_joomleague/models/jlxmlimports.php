<?php
/**
 * Joomleague
 *
 * @copyright	Copyright (C) 2006-2015 joomleague.at. All rights reserved.
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * @link		http://www.joomleague.at
 */

// Check to ensure this file is included in Joomla!
defined('_JEXEC') or die;

/**
 * JLXML-Import Model
 *
 * @author	And_One
*/
class JoomleagueModelJLXMLImports extends JLGModel
{
}
